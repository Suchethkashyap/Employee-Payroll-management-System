localhost/payroll

1)HR Credentials:
Email:sucheth@xyz
Password:sucheth

2)Accountant credential:
Email:nuthan@xyz
Password:nuthan